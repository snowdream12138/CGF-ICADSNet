from ultralytics import YOLO
import os
import numpy as np
import cv2
from pathlib import Path

if __name__ == '__main__':
    # Load a model
    model = YOLO(model=r'/root/detection/yolov8/exp3/weights/best.pt')


    save_dir = Path(r'/root/detection/runs/detect/predict')
    save_dir.mkdir(parents=True, exist_ok=True)

    # Input image directory
    image_dir = r'/root/detection/dataset/test'
    # Output file to save image name and bounding box coordinates
    output_file = r'/root/detection/dataset/bbox_coordinates.txt'

    # Run prediction without automatic saving
    results = model.predict(
        source=image_dir,
        save=False,  
        show=False,   
        conf=0.25   
    )

    # Open the output file to save bounding box coordinates
    with open(output_file, 'w') as f:
        # Parse results to extract coordinates and save to file
        image_files = sorted([f for f in os.listdir(image_dir) if f.endswith(('.jpg', '.jpeg', '.png', '.bmp'))])

        for result, img_name in zip(results, image_files):
            print(f"\nProcessing Image: {img_name}")  # Print image name
            img_path = os.path.join(image_dir, img_name)
            orig_img = cv2.imread(img_path)  

            best_box = None
            max_conf = 0.0
            confidences = []

            for box in result.boxes:  
                conf = box.conf.item() 
                confidences.append(conf)
                if conf > max_conf:
                    max_conf = conf
                    best_box = box

            if best_box is not None:
                from ultralytics.engine.results import Results
                new_result = Results(
                    orig_img=orig_img,
                    path=result.path,
                    names=result.names,
                    boxes=best_box.data.unsqueeze(0)  
                )

                plotted_img = new_result.plot(
                    line_width=2,
                    boxes=True,
                    conf=True,
                    labels=True
                )
                text = f"{img_name}: Conf={max_conf:.2f}"
            else:

                plotted_img = orig_img
                text = f"{img_name}: No detection"


            save_path = os.path.join(save_dir, img_name)
            cv2.imwrite(save_path, plotted_img)

            print(text)

            f.write(f"{img_name}: ")

            if best_box is not None: 
                x1, y1, x2, y2 = map(int, best_box.xyxy[0])
                box_str = f"[{x1}, {y1}, {x2}, {y2}]"
                
                f.write(f"{box_str}\n")
                print(f"Box: {box_str}")
            else:
                f.write("No detection\n")