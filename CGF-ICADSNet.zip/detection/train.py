# -*- coding: utf-8 -*-
import warnings
warnings.filterwarnings('ignore')
from ultralytics import YOLO

if __name__ == '__main__':
    model = YOLO(model=r'/root/detection/ultralytics/cfg/models/v8/my_yolov8.yaml')
    model.train(data=r'data.yaml',
                imgsz=640,
                epochs=300,
                batch=4,
                workers=0,
                device='',
                optimizer='SGD',
                close_mosaic=10,
                resume=False,
                project='yolov8',
                name='exp',
                single_cls=False,
                cache=False
                )